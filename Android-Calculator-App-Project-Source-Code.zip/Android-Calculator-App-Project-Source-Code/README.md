# A simple Android calculator app

